import os
import sys

sys.argv.append(os.path.abspath("./ncchinfo_gen.py"))
for file in os.listdir("../Encrypted"):
    if file.endswith(".3ds") or file.endswith(".3DS"):
        print os.path.abspath("../Encrypted/" + file)
        sys.argv.append(os.path.abspath("../Encrypted/" + file))

print sys.argv
execfile('./ncchinfo_gen.py')
