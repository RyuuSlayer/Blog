=============================================================================================================================================

## How To ##

1. Ensure the '.run' folder was not deleted (it may be hidden on your system) as it contains all the necessary executables and files.

2. Place any and all roms directly into the 'roms' folder, and not in subfolders. The one exception is cdn files, which MUST be inside of a subfolder.

3. Run the 'run_script.bat' batch script to get started. Navigating the menus should be simple and fairly intuitive.

=============================================================================================================================================

## Tips ##

- Decrypting/Encrypting or Trimming/Untrimming 3ds roms are done in place, meaning the source file will be modified. To revert, you can simply run the opposite and the file will return to its original form and CRC to match. NOTE: Some roms may not work properly after being trimmed.

- When converting 3ds roms to cia format, the cia will always be decrypted. If the source rom is encrypted however, you must have the boot9.bin bios file inside the '.run' folder. This file may be missing, in which case you will need to search for it (CRC=E0989F6D) or decrypt the rom first.

- When converting DSiWare roms to cia, they must be decrypted in .nds format. (if the file does not have an extension or is .dsi, you can add/rename it).

- When converting cdn files to cia, you will need the cdn game files (example, the 0000000 files) along with the 'tmd' and 'cetk' files. To get the cetk files for a game, you can use a tool such as https://www.cpokemon.com/labs/tik/index.php or https://github.com/HouseBreaker/Shameless to download the .tik for the title, and then rename it to cetk (exact file name, without any extentions).

- When converting cdn files to cia, if you get an error like:
  [!] Caution, Ticket and TMD Title Versions do not match
  [!] CETK Title Ver: 1
  [!] TMD Title Ver: 16

  "The 'title version' is not checked when installing the CIA or playing the game on custom firmware so the game will install and work fine, but if you want a 'proper' CIA you can fix the error by opening the 'tmd' and 'cetk' files in a hex editor, copying the two bytes of 'title version' data (e.g 00 10) in the TMD file located at '0x01DC and 0x01DD', then going to the ticket at '0x01E6 and 0x01E7' and pasting / entering those two bytes of version data, then saving the ticket and rebuilding the CIA"
  Source: https://gbatemp.net/threads/how-to-convert-a-cdn-game-tik-tmd-app-to-a-cia-file.515929/#post-8250640

- All .cia files are able to be installed to any 2ds/3ds with CFW using FBI. NOTE: DSiWare titles are installed to the NAND (NOT the SD card!) so be mindful of the limited NAND storage capacity.

- Some features such as decrypting cias or converting them to 3ds roms is experimental and not fully supported. There will be CRC mismatches to no-intro sets every time. Use at your own risk.

- Decrypting cias has known limitations. It must not include the character '!' in the name (Exclamation mark) and there's a length to the number of NCCH files from the CIA (500+).

- If you prefer, you can change what folders the script will look for roms in and output to by editing the variables at the top of the script to whichever path/rom folders you prefer.

=============================================================================================================================================

## Versions ##

4 - Fixed cia decrypt (Still experimental) and cnd->cia conversion not working correctly since version 3. Better support for decrypting update and dlc cias

3 - Fixed rom files with '!' not working. Removed 7z support

2 - Fixes and cleaned up code

1 - Initial Release

=============================================================================================================================================

## Credits ##

None of the tools used in this script were made by me, I just put them all together. Full credit goes to the authors below:

3dsconv.exe - ihaveamac @ https://github.com/ihaveamac/3dsconv
encrypt & decrypt tools - ???? (If you know, please let me know!)
rom_tool.exe & make_cia.exe & make_cdn_cia.exe - 3DSGuy @ https://github.com/Tiger21820/ctr_toolkit
decrypt.exe - 54634564
makerom.exe & ctrtool.exe - profi200
Script Author - Nomelas@GBAtemp

=============================================================================================================================================